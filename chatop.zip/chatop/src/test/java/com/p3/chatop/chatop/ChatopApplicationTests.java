package com.p3.chatop.chatop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatopApplicationTests {

	@Test
	void contextLoads() {
	}

}
